import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF', // Changed to white background like welcome screen
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#E18731',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  // progressContainer: {
  //   marginBottom: 15,
  // },
  // progressBackground: {
  //   height: 6,
  //   backgroundColor: '#F5F5F5',
  //   borderRadius: 3,
  //   marginBottom: 10,
  // },
  // progressBar: {
  //   height: '100%',
  //   backgroundColor: '#E17731', // Brand color
  //   borderRadius: 3,
  // },
  // progressText: {
  //   fontSize: 16,
  //   color: '#666666',
  //   textAlign: 'center',
  //   fontWeight: '500',
  //   letterSpacing: 0.5,
  // },
  // timerContainer: {
  //   alignItems: 'center',
  //   marginTop: 5,
  // },
  // timerText: {
  //   fontSize: 18,
  //   fontWeight: '600',
  //   color: '#333333',
  //   letterSpacing: 0.5,
  // },
  // timerWarning: {
  //   color: '#E74C3C',
  // },
  questionContainer: {
    flex: 1,
    padding: 20,
    paddingTop: 10,
    marginTop: 10,
  },
  questionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    marginBottom: 25,
    borderWidth: 2,
    borderColor: '#E8E8E8',
    // shadowColor: '#E18731',
    // shadowOffset: {
    //   width: 0,
    //   height: 4,
    // },
    // shadowOpacity: 0.1,
    // shadowRadius: 12,
    // elevation: 6,
  },
  questionHeader: {
    alignItems: 'center',
    marginBottom: 0,
  },
  questionNumber: {
    backgroundColor: '#E18731',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 10,
  },
  questionNumberText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  levelLabel: {
    fontSize: 14,
    color: '#E18731', // Brand color
    fontWeight: '600',
    marginBottom: 15,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  questionText: {
    fontSize: 18,
    color: '#333333',
    lineHeight: 26,
    fontWeight: '500',
    textAlign: 'center',
  },
  answersContainer: {
    gap: 25,
  },
  answerButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 35,
    padding: 18,
    borderWidth: 2,
    borderColor: '#F0F0F0',
    // shadowColor: '#E18731',
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.08,
    // shadowRadius: 8,
    // elevation: 3,
  },
  selectedAnswer: {
    borderColor: '#E18731',
    backgroundColor: '#FFF8F5', // Light orange background
    shadowOpacity: 0.15,
  },
  answerOption: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  answerLabel: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#E18731', // Brand color
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 28,
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 15,
  },
  answerText: {
    fontSize: 16,
    color: '#333333',
    flex: 1,
    lineHeight: 22,
    fontWeight: '400',
  },
  selectedAnswerText: {
    color: '#333333',
    fontWeight: '500',
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    elevation: 5,
  },
  navButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 25,
    backgroundColor: '#F5F5F5',
    minWidth: 90,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  disabledButton: {
    backgroundColor: '#F8F8F8',
    shadowOpacity: 0,
    elevation: 0,
  },
  navButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333333',
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  disabledButtonText: {
    color: '#CCCCCC',
  },
  submitButton: {
    backgroundColor: '#E18731', // Brand color
    paddingVertical: 12,
    paddingHorizontal: 28,
    borderRadius: 25,
    shadowColor: '#E18731',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 1,
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  loadingText: {
    fontSize: 18,
    color: '#666666',
    fontWeight: '500',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  errorText: {
    fontSize: 18,
    color: '#E74C3C',
    fontWeight: '500',
    textAlign: 'center',
  },
});