import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from '../../apiConfig';

// const API_URL = "http://localhost:8000/api/bible/quizzes/user";

const getToken = async () => {
  return await AsyncStorage.getItem('userToken');
};

export const fetchCurrentUser = async () => {
  try {
    const token = await getToken();

    const response = await axios.get(`${BASE_URL}/bible/quizzes/user`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "*/*",
      },
    });

    return response.data;
  } catch (error) {
    console.error("Error fetching current user:", error.response?.data || error.message);
    throw error;
  }
};
