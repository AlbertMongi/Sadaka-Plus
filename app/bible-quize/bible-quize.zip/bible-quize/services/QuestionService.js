import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../apiConfig";

// const API_BASE = "http://localhost:8000/api/bible/quizzes";

const getToken = async () => {
  return await AsyncStorage.getItem('userToken');
};

export const QuestionService = {

  startQuiz: async (level) => {
    const res = await fetch(`${BASE_URL}/bible/quizzes/session/start`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${await getToken()}`,
        "Content-Type": "application/json",
        Accept: "*/*",
      },
      body: JSON.stringify({ level }),
    });

    if (!res.ok) {
      throw new Error(`Failed to start quiz: ${res.status}`);
    }

    const data = await res.json();
    // Normalize questions so they look like your UI expects
    return {
      sessionId: data.sessionId,
      questions: data.questions.map((q) => ({
        id: q.id,
        question: q.question,
        options: Object.values(q.options), // convert {A: "Adam", B: "..."} → ["Adam","..."]
        optionKeys: Object.keys(q.options), // ["A","B","C","D"] so we can map answers back
        level: q.level,
        points: q.points,
      })),
    };
  },

  submitAnswers: async (sessionId, answers) => {
    const res = await fetch(`${BASE_URL}/bible/quizzes/session/${sessionId}/submit`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${await getToken()}`,
        "Content-Type": "application/json",
        Accept: "*/*",
      },
      body: JSON.stringify(answers),
    });

    if (!res.ok) {
      throw new Error(`Failed to submit quiz: ${res.status}`);
    }

    return res.json();
  },
};
