import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ScrollView,
  Animated,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
// import { useRouter } from "expo-router";
import { QuestionService } from '../services/QuestionService';
import { styles } from '../styles/QuizScreen.styles';
// import NavigationBar from '../components/NavigationBar';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

const QuizScreen = () => {
  const navigation = useNavigation();
  const router = useRouter();
  const { level, levelName } = useLocalSearchParams();
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [loading, setLoading] = useState(true);
  const [progress] = useState(new Animated.Value(0));
  const [fadeAnim] = useState(new Animated.Value(0));
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
    loadQuestions();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer); // cleanup
  }, []);

  useEffect(() => {
    updateProgressBar();
    animateFadeIn();
  }, [currentQuestionIndex]);

  const loadQuestions = async () => {
    try {
      const { sessionId, questions } = await QuestionService.startQuiz(level);
      setSessionId(sessionId);
      setQuestions(questions);
      setLoading(false);
    } catch (error) {
      console.error("Error loading questions:", error);
      Alert.alert("Error", "Failed to load questions. Please try again.");
    }
  };

  const handleAnswerSelect = (answerIndex) => {
    const q = questions[currentQuestionIndex];
    const optionKey = q.optionKeys[answerIndex];
    setSelectedAnswers((prev) => ({
      ...prev,
      [q.id]: optionKey, // store by question id
    }));
  };

  const submitQuiz = async () => {
    try {
      const results = await QuestionService.submitAnswers(sessionId, selectedAnswers);
      router.push({
        pathname: "/bible-quize/screens/ResultScreen",
        params: { results: JSON.stringify(results) },
      });
    } catch (err) {
      console.error("Submit error:", err);
      Alert.alert("Error", "Failed to submit quiz.");
    }
  };

  const updateProgressBar = () => {
    const progressValue = (currentQuestionIndex + 1) / questions.length;
    Animated.timing(progress, {
      toValue: progressValue,
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const animateFadeIn = () => {
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 400,
      useNativeDriver: true,
    }).start();
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  const handleSubmitQuiz = () => {
    const answeredCount = Object.keys(selectedAnswers).length;
    const unansweredCount = questions.length - answeredCount;

    if (unansweredCount > 0 && timeLeft > 0) {
      Alert.alert(
        'Incomplete Quiz',
        `You have ${unansweredCount} unanswered questions. Submit anyway?`,
        [
          { text: 'Continue Quiz', style: 'cancel' },
          { text: 'Submit', onPress: submitQuiz },
        ]
      );
    } else {
      submitQuiz();
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading Questions...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (questions.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>No questions available</Text>
        </View>
      </SafeAreaView>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === questions.length - 1;
  const selectedOptionKey = selectedAnswers[currentQuestion.id]; 

  return (
    <SafeAreaView style={styles.container}>
      {/* <NavigationBar navigation={navigation} points={20} /> */}
      
      <ScrollView style={styles.questionContainer} showsVerticalScrollIndicator={false}>
        <Animated.View style={{ opacity: fadeAnim }}>
          <View style={styles.questionCard}>
            <View style={styles.questionHeader}>
              <View style={styles.questionNumber}>
                <Text style={styles.questionNumberText}>
                  Question {currentQuestionIndex + 1}/{questions.length}
                </Text>
              </View>
              <Text style={styles.levelLabel}>{levelName}</Text>
            </View>
            <Text style={styles.questionText}>{currentQuestion.question}</Text>
          </View>

          <View style={styles.answersContainer}>
            {currentQuestion.options.map((option, index) => {
              const optionKey = currentQuestion.optionKeys[index];
              const isSelected = selectedOptionKey === optionKey; 
              return (
                <TouchableOpacity
                  key={index}
                  style={[styles.answerButton, isSelected && styles.selectedAnswer]}
                  onPress={() => handleAnswerSelect(index)}
                >
                  <View style={styles.answerOption}>
                    <Text style={styles.answerLabel}>
                      {String.fromCharCode(65 + index)}
                    </Text>
                    <Text style={[styles.answerText, isSelected && styles.selectedAnswerText]}>
                      {option}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          <View style={styles.navigationContainer}>
            <TouchableOpacity
              style={[styles.navButton, currentQuestionIndex === 0 && styles.disabledButton]}
              onPress={handlePreviousQuestion}
              disabled={currentQuestionIndex === 0}
            >
              <Text
                style={[
                  styles.navButtonText,
                  currentQuestionIndex === 0 && styles.disabledButtonText,
                ]}
              >
                Previous
              </Text>
            </TouchableOpacity>

            {isLastQuestion ? (
              <TouchableOpacity style={styles.submitButton} onPress={handleSubmitQuiz}>
                <Text style={styles.submitButtonText}>Submit Quiz</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.navButton} onPress={handleNextQuestion}>
                <Text style={styles.navButtonText}>Next</Text>
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default QuizScreen;
