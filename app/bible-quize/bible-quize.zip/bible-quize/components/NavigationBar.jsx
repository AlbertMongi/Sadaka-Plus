import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Ionicons';
import { useRouter } from 'expo-router';
import { useNavigation } from '@react-navigation/native';
import { fetchCurrentUser } from "../services/userService";

const NavigationBar = ({ navigations, points }) => {
  const router = useRouter();
  const navigation = useNavigation();
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const data = await fetchCurrentUser();
      setUser(data);
    } catch (error) {
      console.error("Failed to load user:", error);
    }
  };


  const handgleLeaderboard = () => {
    router.push('/bible-quize/screens/LeaderboardScreen');
  }

  const handleSettings = () => {
    router.push('/bible-quize/screens/SettingScreen');
  }

  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <View style={styles.container}>
        {/* Left: Back Button */}
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back" size={24} color="#E17731" />
        </TouchableOpacity>

        {/* Right: Points + Icons */}
        <View style={styles.rightContainer}>
          <Text style={styles.points}>
            {user ? `${user.score} pts` : "0 pts"}
          </Text>

          <TouchableOpacity onPress={handleSettings}>
            <Icon name="settings-outline" size={24} color="#333" style={styles.icon} />
          </TouchableOpacity>

          <TouchableOpacity onPress={handgleLeaderboard}>
            <Icon name="trophy-outline" size={24} color="#333" style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default NavigationBar;

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: '#fff', // background under status bar
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
  },
  rightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  points: {
    fontSize: 14,
    fontWeight: '600',
    marginRight: 10,
    backgroundColor: '#FFF3E0',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    color: '#333',
  },
  icon: {
    marginLeft: 10,
  },
});
